class ApplicationController < ActionController::Base
  # Only allow modern browsers supporting webp images, web push, badges, import maps, CSS nesting, and CSS :has.
  # Skip browser check in test environment to allow test runners
  allow_browser versions: :modern unless Rails.env.test?

  # CSRF protection for all controllers
  protect_from_forgery with: :exception

  before_action :set_theme

  protected

  def current_user_session
    # Test environment: also check for test_user_id cookie for system tests
    if Rails.env.test? && cookies[:test_user_id].present?
      @current_user_session ||= User.find_by(id: cookies[:test_user_id])
    elsif session[:user_id]
      @current_user_session ||= User.find_by(id: session[:user_id])
    end
  end

  helper_method :current_user_session

  def require_user_session
    return if current_user_session

    message = "Session expired. Please sign in again."
    session.delete(:user_id)
    cookies.delete(:test_user_id)
    redirect_to root_path, alert: message
  end

  def current_theme
    @current_theme
  end

  helper_method :current_theme

  private

  def set_theme
    requested_theme = cookies[:theme]
    @current_theme = %w[light dark].include?(requested_theme) ? requested_theme : "dark"
  end
end
